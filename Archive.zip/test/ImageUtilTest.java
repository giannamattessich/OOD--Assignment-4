public class ImageUtilTest {
}
